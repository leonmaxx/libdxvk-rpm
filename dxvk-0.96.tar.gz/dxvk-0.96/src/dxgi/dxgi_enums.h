#pragma once

#include "dxgi_include.h"

std::ostream& operator << (std::ostream& os, DXGI_FORMAT e);
