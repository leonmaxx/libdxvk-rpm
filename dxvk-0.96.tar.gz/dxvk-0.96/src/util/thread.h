#ifdef DXVK_NATIVE
  #include "thread_generic.h"
#else
  #include "thread_win32.h"
#endif