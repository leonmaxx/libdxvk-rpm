#pragma once

#include <ostream>

#include "d3d11_include.h"

std::ostream& operator << (std::ostream& os, D3D_FEATURE_LEVEL e);