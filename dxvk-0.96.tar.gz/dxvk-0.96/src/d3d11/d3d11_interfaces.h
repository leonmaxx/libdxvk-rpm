#pragma once

#include "d3d11_include.h"

#include "../dxgi/dxgi_interfaces.h"

#include "../dxvk/dxvk_device.h"
