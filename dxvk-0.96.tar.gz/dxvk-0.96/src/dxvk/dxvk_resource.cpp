#include "dxvk_resource.h"

namespace dxvk {
  
  DxvkResource::~DxvkResource() {
    
  }
  
}