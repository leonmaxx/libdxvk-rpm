#pragma once

#include "../dxgi/dxgi_include.h"
#include "../util/sync/sync_spinlock.h"

#include <d3d10_1.h>
#include <d3d11_1.h>