# dxvk-native-headers
Slightly modified wine headers for compilation of dxvk-native
